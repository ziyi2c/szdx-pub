<template>
  <div class="search">
    <el-row class="btns" align="middle">
      <el-col :span="24" class="col">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-form-item label="地区">
            <el-input v-model.trim="conditions.area" placeholder="请输入城市中文名称"></el-input>
          </el-form-item>
          <el-form-item label="专业">
            <el-input v-model.trim="conditions.key" placeholder="请输入专业关键字"></el-input>
          </el-form-item>
          <el-form-item label="最低薪酬">
            <el-input v-model.number="conditions.low" placeholder="请输入数字"></el-input>
          </el-form-item>
          <el-form-item label="最高薪酬">
            <el-input v-model.number="conditions.high" placeholder="请输入数字"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="onSubmit">查询</el-button>
          </el-form-item>
        </el-form>
      </el-col>
    </el-row>
    <el-row class="infos">
      <el-col :span="24">
        <p class="showResult" v-if="show === true">{{ temp.area }}、{{ temp.key }}，月薪{{ temp.low }}-{{ temp.high }}万，现有用人单位有:{{ result.dw }}家，提供岗位:{{ result.gw }}个。</p>
        <p class="showResult" v-else>Loading...</p>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data() {
    return {
      conditions: {
        area: '成都',
        key: '大数据',
        high: 1,
        low: 0
      },
      result: {
        dw: 0,
        gw: 0
      },
      show: true,
      temp: {
        area: '成都',
        key: '大数据',
        high: 1,
        low: 0
      }
    };
  },
  methods: {
    onSubmit() {
      this.show = false;
      this.search();
      this.temp = this.conditions;
    },
    async search() {
      await this.$http
        .post('/api/search', {
          data: this.conditions
        })
        .then(resp => {
          console.log(resp.data);
          const { data: res } = resp;
          this.result.dw = res.data.gs;
          this.result.gw = res.data.gw;
          this.show = true;
        });
    }
  }
};
</script>

<style lang="less" scoped>
.search {
  margin: 20px auto 0 auto;
  width: 1170px;
  height: 45vh;
  border-radius: 7px;
  overflow: hidden;
  box-shadow: 0 0 10px #e3e4e4;
  .btns {
    height: 20vh;
    // background-color: pink;
    background-color: #ffffff80;
  }
  .infos {
    height: 300px;
    background-color: #ffffff80;
    p {
      font-size: 22px;
      font-weight: bold;
    }
  }
  .cols {
    display: flex;
    align-items: center;
    justify-content: center;
  }
}
</style>
