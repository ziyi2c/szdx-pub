<template>
  <div class="title">
    <h1>demo</h1>
  </div>
</template>

<script>
export default {};
</script>

<style lang="less" scoped>
.title {
  height: 100%;
  display: flex;
  // align-items: center;
  // justify-content: center;
}
h1 {
  margin: auto;
  // line-height: 10vh;
  // line-height: 400%;
  color: #2e4257;
}
</style>
